function displayRoom() {

    var t = document.getElementById("roomInput").value;

    var roomnumber = document.getElementById(t).dataset.number;


    if (t == parseInt(roomnumber)) {
        document.getElementById(roomnumber).style.visibility = "visible";
    }

    return roomnumber;
}

function reset() {
    var hideDivs = document.getElementsByClassName('room');
    for (var i = 0; i < hideDivs.length; i++) {
        hideDivs[i].style.visibility = "hidden";
    }
    
}